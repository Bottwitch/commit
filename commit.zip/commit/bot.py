import os
import twitter


tweets = 0
searchs = 0
limitTweets = 300
limitSearch = 180

api = twitter.Api(consumer_key= "JUpM4BQujBT4JCx6xxOMO2kuZ",
                  consumer_secret= "nlOqxawdNI7kbYvzrvIH0gf3EiIaRY4P4mgWJihvFFvm6u556s",
                  access_token_key= "1434102181351788547-0oawxSqaMGX0I4SHZkgvZa18ubQVwa",
                  access_token_secret= "STO7TB1ISSmpl3S3uykFRptePC33uJcL32p9NFWk8g2Ik")





def postStatus(update, inReplyTo, media):
    global tweets 
    tweets += 1
    api.PostUpdate(update, media=media, in_reply_to_status_id=inReplyTo)
    


def search(research, howMany):
    global searchs 
    searchs += 1
    searchResults = api.GetSearch(raw_query="q="+research+"&result_type=recent&count="+howMany)
    for search in searchResults:
        if(search.text, "twich.tv"):
            
            postStatus("@" + search.user.screen_name + " streamer c'est pas un vrai metier", search.id, "gneu.jpg")


def start():
    global searchs 
    global tweets 
    while True:
        search("twich.tv", "100")
        if searchs  >= limitSearch:
            print("limite atteinte des searchs")
            time.sleep(900)
            searchs = 0
        elif tweets >= limitTweets:
            print("limite atteinte des tweets")
            time.slepp(3600)
            tweets = 0
        print("on a tweeté " + str(tweets) + " fois !")
        time.sleep(5)


start()





























































































